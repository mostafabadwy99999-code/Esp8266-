/*
  ============================================================
  Mostafa_Badawy_Controller_V2  -  ESP8266 Smart Control Panel
  ============================================================
  - 6 مفاتيح (ريليهات) بتصميم عصري شبه Tuya Smart
  - تايمر مواعيد (كشاف يفتح ويقفل في ساعات تحددها انت بنفسك، مبني على وقت الإنترنت NTP)
  - زرار طوارئ فيزيائي + من المتصفح (يشغل أول 4 مفاتيح ويبعت إشعار موبايل)
  - سويتشات (Toggle) بدل الأزرار
  - Bottom Navigation Bar بالأيقونات
  - اسم عام للجهاز (Panel Title) قابل للتعديل
  - تحديث الفيرموير عن بُعد (OTA) عن طريق رفع ملف .bin من المتصفح
  - نسخ احتياطي واسترجاع لكل الإعدادات (Backup / Restore) كملف JSON
  - صفحة WiFi Settings (اتصال + Access Point دايمًا شغالة)
  - صفحة MQTT Settings (Broker / Prefix / Port)
  - حفظ كل الإعدادات في الفلاش (Preferences)
  - تأكيد (Confirm) قبل الريستارت أو مسح الإعدادات
  - دعم MQTT: topics
        prefix/control/relayX   ->  ON / OFF
        prefix/status/relayX    ->  ON / OFF
        prefix/control/all      ->  ON / OFF
        prefix/status/all       ->  ON / OFF

  المكتبات (PlatformIO هيحملها لوحده من platformio.ini):
   - PubSubClient (knolleary)
  ============================================================
*/

#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <Preferences.h>
#include <PubSubClient.h>
#include <Updater.h>
#include <ArduinoJson.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecure.h>
#include <time.h>
#include <SHA256.h> // مكتبة Crypto (rweather) - بديل خفيف لـ mbedtls (مش متوفرة على ESP8266/BearSSL)

// ------------------- إعدادات البينات (ESP8266 - NodeMCU / Wemos D1 mini) -------------------
// 6 ريليهات بس، على البينات الآمنة تمامًا واللي ملهاش أي علاقة بمنطق الإقلاع (Boot)
// خريطة الأرقام:  D1=GPIO5  D2=GPIO4  D5=GPIO14  D6=GPIO12  D7=GPIO13  D0=GPIO16
#define RELAY_COUNT 6
const int relayPins[RELAY_COUNT] = {5, 4, 14, 12, 13, 16}; // D1, D2, D5, D6, D7, D0
// D3(GPIO0) و D4(GPIO2) سايبينهم فاضيين تمامًا، مفيش أي حمل عليهم وقت الإقلاع خالص


// ------------------- زرار الطوارئ (Emergency Button) -------------------
// وصّل زرار (طرف في الجراوند GND والطرف التاني في البين دا) - استخدمنا بين RX لأنه فاضي
// ملحوظة: لو موصل زرار على RX، متستخدمش السيريال مونيتور وقت التشغيل العادي (هيتعارض)
const int emergencyButtonPin = 3; // RX (GPIO3)
const int EMERGENCY_RELAY_COUNT = 4; // أول 4 مفاتيح بس اللي بتشتغل وقت الطوارئ
const unsigned long EMERGENCY_DURATION = 30UL * 60UL * 1000UL; // 30 دقيقة
const unsigned long EMERGENCY_RETRIGGER_COOLDOWN = 5000; // ميلي ثانية - يمنع تكرار التفعيل بضغطة واحدة

bool emergencyActive = false;
unsigned long emergencyStartTime = 0;
bool emergencyButtonHeld = false;
unsigned long emergencyLastTrigger = 0;
bool emergencyButtonEnabled = true; // لو false، الزرار الفيزيائي مش هيشتغل (وضع "أنا موجود في البيت")

// أنهي ريليهات هتشتغل وقت الطوارئ (على البورد ده بالذات) - قابلة للتعديل من صفحة Emergency
// الافتراضي: أول 4 ريليهات (زي ما كان قبل كده)
bool emergencyRelayEnabled[RELAY_COUNT] = {true, true, true, true, false, false};

// توبيك MQTT مشترك بين البوردين - لو اتحط، البورد ده هيبعت عليه لما الطوارئ تتفعل/تتلغي
// وهيسمعه كمان، فلو بورد تاني بعت عليه، البورد ده هيفعّل/يلغي الطوارئ عنده تلقائي
// لازم تكتب نفس الاسم بالظبط في البوردين التنين، وميتلخبطش مع mqttPrefix بتاع كل بورد
String emergencyShareTopic = "";

// ------------------- إعدادات إشعارات ntfy.sh -------------------
// تطبيق ntfy مجاني وبيبعت إشعار فوري للموبايل من غير تسجيل حساب
// نزّل تطبيق ntfy من المتجر واعمل Subscribe لنفس اسم التوبيك اللي هتكتبه هنا
String ntfyTopic = "";

// أغلب لوحات الريليه الجاهزة بتشتغل بمنطق معكوس (LOW = تشغيل، HIGH = إيقاف)
// لو الريليهات عندك عكس (تفتح لما المفروض تقفل)، سيب القيمة true
// لو عايز ترجعها للوضع العادي (HIGH = تشغيل)، خليها false
const bool RELAY_ACTIVE_LOW = true;

// حالة كل ريليه
bool relayState[RELAY_COUNT] = {false, false, false, false, false, false};

// أسماء افتراضية للريليهات
String relayNames[RELAY_COUNT] = {
  "كشاف شمال", "كشاف الوجهه", "كشاف البوابه", "كشاف يمين", "ريليه 5", "ريليه 6"
};

String panelTitle = "Mostafa Badawy Controller";
String peerBoardUrl = ""; // آي بي أو اسم البورد التاني على نفس الشبكة (للتنقل بينهم من أيقونة 🔀)

// ------------------- تايمر يومي لكل كشاف (كل ريليه له جدول تشغيل/إيقاف خاص بيه) -------------------
bool schedEnabled[RELAY_COUNT]   = {false, false, false, false, false, false};
int schedOnHour[RELAY_COUNT]     = {18, 18, 18, 18, 18, 18}; // الساعة اللي هيفتح فيها كل ريليه (نظام 24 ساعة)
int schedOnMinute[RELAY_COUNT]   = {0, 0, 0, 0, 0, 0};
int schedOffHour[RELAY_COUNT]    = {6, 6, 6, 6, 6, 6};       // الساعة اللي هيقفل فيها كل ريليه
int schedOffMinute[RELAY_COUNT]  = {0, 0, 0, 0, 0, 0};
int schedGmtOffset = 2;   // فرق التوقيت عن جرينتش بالساعات، مشترك لكل الجداول (مصر = 2)

// ------------------- إعدادات الشبكة -------------------
String staSsid = "";
String staPass = "";

// حجز IP ثابت للبورد نفسه (بدل ما ياخد IP عشوائي كل مرة من الروتر)
// لازم تكتب بيانات صح ومتوافقة مع شبكتك (الجيت واي والسبنت ماسك بتوع الروتر عندك)
bool staUseStaticIp = false;
String staStaticIp = "";       // مثال: 192.168.1.200
String staStaticGateway = "";  // مثال: 192.168.1.1 (عادة هو نفسه IP بتاع الروتر)
String staStaticSubnet = "255.255.255.0";
String staStaticDns = "";      // اختياري، لو فاضي هيستخدم نفس الجيت واي

String apSsid = "Mostafa Home";
String apPass = "MOstafa@2000";
bool apHidden = false;

// ------------------- إعدادات MQTT -------------------
String mqttBroker = "broker.hivemq.com";
String mqttPrefix = "mostafabadawy";
int mqttPort = 1883;
bool mqttEnabled = true;

// مفتاح الربط (Pairing Key) - نفس المفتاح لازم يكون متحط في إعدادات التطبيق.
// بيُستخدم لحساب توقيع HMAC-SHA256 لرسالة الاكتشاف (discovery) عشان التطبيق
// يتأكد إن الرسالة جاية من الفيرموير بتاعك انت بس، مش من أي بورد تاني.
String pairingKey = "";

ESP8266WebServer server(80);
Preferences prefs;

String restoreBuffer = "";
bool otaUploadOk = false;
String otaErrorMsg = "";

WiFiClient espClient;
PubSubClient mqttClient(espClient);

// ============================================================
//                       تخزين الإعدادات
// ============================================================
void loadSettings() {
  prefs.begin("mostafabdw", true);

  staSsid = prefs.getString("sta_ssid", "");
  staPass = prefs.getString("sta_pass", "");

  staUseStaticIp  = prefs.getBool("sip_en", false);
  staStaticIp      = prefs.getString("sip_ip", "");
  staStaticGateway = prefs.getString("sip_gw", "");
  staStaticSubnet  = prefs.getString("sip_sub", "255.255.255.0");
  staStaticDns     = prefs.getString("sip_dns", "");

  apSsid   = prefs.getString("ap_ssid", apSsid);
  apPass   = prefs.getString("ap_pass", apPass);
  apHidden = prefs.getBool("ap_hidden", false);

  mqttBroker = prefs.getString("mqtt_broker", mqttBroker);
  mqttPrefix = prefs.getString("mqtt_prefix", mqttPrefix);
  mqttPort   = prefs.getInt("mqtt_port", mqttPort);
  pairingKey = prefs.getString("pairing_key", pairingKey);

  panelTitle = prefs.getString("panel_title", panelTitle);

  ntfyTopic = prefs.getString("ntfy_topic", ntfyTopic);
  emergencyButtonEnabled = prefs.getBool("em_btn_en", true);
  emergencyShareTopic = prefs.getString("em_sh_top", "");

  schedGmtOffset = prefs.getInt("sch_gmt", 2);
  peerBoardUrl   = prefs.getString("peer_ip", "");

  for (int i = 0; i < RELAY_COUNT; i++) {
    String nameKey  = "rn_" + String(i);
    relayNames[i]   = prefs.getString(nameKey.c_str(), relayNames[i]);

    emergencyRelayEnabled[i] = prefs.getBool(("em_rl" + String(i)).c_str(), i < EMERGENCY_RELAY_COUNT);

    schedEnabled[i]   = prefs.getBool(("sc_en" + String(i)).c_str(), false);
    schedOnHour[i]     = prefs.getInt(("sc_onh" + String(i)).c_str(), 18);
    schedOnMinute[i]   = prefs.getInt(("sc_onm" + String(i)).c_str(), 0);
    schedOffHour[i]    = prefs.getInt(("sc_ofh" + String(i)).c_str(), 6);
    schedOffMinute[i]  = prefs.getInt(("sc_ofm" + String(i)).c_str(), 0);
  }

  prefs.end();
}

void saveWifiSettings(String ssid, String pass) {
  prefs.begin("mostafabdw", false);
  prefs.putString("sta_ssid", ssid);
  prefs.putString("sta_pass", pass);
  prefs.end();
}

void saveStaticIpSettings(bool en, String ip, String gw, String sub, String dns) {
  prefs.begin("mostafabdw", false);
  prefs.putBool("sip_en", en);
  prefs.putString("sip_ip", ip);
  prefs.putString("sip_gw", gw);
  prefs.putString("sip_sub", sub);
  prefs.putString("sip_dns", dns);
  prefs.end();
}

void saveApSettings(String ssid, String pass, bool hidden) {
  prefs.begin("mostafabdw", false);
  prefs.putString("ap_ssid", ssid);
  prefs.putString("ap_pass", pass);
  prefs.putBool("ap_hidden", hidden);
  prefs.end();
}

void saveMqttSettings(String broker, String prefix, int port) {
  prefs.begin("mostafabdw", false);
  prefs.putString("mqtt_broker", broker);
  prefs.putString("mqtt_prefix", prefix);
  prefs.putInt("mqtt_port", port);
  prefs.end();
}

void savePairingKey(String key) {
  prefs.begin("mostafabdw", false);
  prefs.putString("pairing_key", key);
  prefs.end();
}

void saveRelayNamesAndTimers() {
  prefs.begin("mostafabdw", false);
  for (int i = 0; i < RELAY_COUNT; i++) {
    String nameKey  = "rn_" + String(i);
    prefs.putString(nameKey.c_str(), relayNames[i]);
  }
  prefs.end();
}

void savePanelTitle(String title) {
  prefs.begin("mostafabdw", false);
  prefs.putString("panel_title", title);
  prefs.end();
}

void saveNtfyTopic(String topic) {
  prefs.begin("mostafabdw", false);
  prefs.putString("ntfy_topic", topic);
  prefs.end();
}

void saveEmergencyButtonEnabled(bool en) {
  prefs.begin("mostafabdw", false);
  prefs.putBool("em_btn_en", en);
  prefs.end();
}

void saveScheduleForRelay(int i, bool en, int onH, int onM, int offH, int offM) {
  prefs.begin("mostafabdw", false);
  prefs.putBool(("sc_en" + String(i)).c_str(), en);
  prefs.putInt(("sc_onh" + String(i)).c_str(), onH);
  prefs.putInt(("sc_onm" + String(i)).c_str(), onM);
  prefs.putInt(("sc_ofh" + String(i)).c_str(), offH);
  prefs.putInt(("sc_ofm" + String(i)).c_str(), offM);
  prefs.end();
}

void saveScheduleGmt(int gmt) {
  prefs.begin("mostafabdw", false);
  prefs.putInt("sch_gmt", gmt);
  prefs.end();
}

void savePeerBoard(String url) {
  prefs.begin("mostafabdw", false);
  prefs.putString("peer_ip", url);
  prefs.end();
}

void saveEmergencyShareTopic(String topic) {
  prefs.begin("mostafabdw", false);
  prefs.putString("em_sh_top", topic);
  prefs.end();
}

void saveEmergencyRelaySelection() {
  prefs.begin("mostafabdw", false);
  for (int i = 0; i < RELAY_COUNT; i++) {
    prefs.putBool(("em_rl" + String(i)).c_str(), emergencyRelayEnabled[i]);
  }
  prefs.end();
}

void clearAllSettings() {
  prefs.begin("mostafabdw", false);
  prefs.clear();
  prefs.end();
}

// ============================================================
//                       MQTT (Forward declarations)
// ============================================================
void publishStatus(int index);
void publishAllStatus();
void publishDiscovery();

// ============================================================
//                       التحكم في الريليهات
// ============================================================
void setRelay(int index, bool state) {
  if (index < 0 || index >= RELAY_COUNT) return;
  relayState[index] = state;
  digitalWrite(relayPins[index], RELAY_ACTIVE_LOW ? (state ? LOW : HIGH) : (state ? HIGH : LOW));
  publishStatus(index);
}

void setAllRelays(bool state) {
  for (int i = 0; i < RELAY_COUNT; i++) {
    if (i == 4) continue; // ريليه 5 مستثنى من زرار "الكل" - بيتحكم فيه لوحده بس
    setRelay(i, state);
  }
  publishAllStatus();
}

// ============================================================
//         تايمر يومي لكل كشاف (كل ريليه بجدول تشغيل/إيقاف مستقل)
// ============================================================
void checkSchedule() {
  bool anyEnabled = false;
  for (int i = 0; i < RELAY_COUNT; i++) {
    if (schedEnabled[i]) { anyEnabled = true; break; }
  }
  if (!anyEnabled) return;

  static unsigned long lastCheck = 0;
  unsigned long now = millis();
  if (now - lastCheck < 15000) return; // فحص كل 15 ثانية يكفي
  lastCheck = now;

  time_t t = time(nullptr);
  if (t < 1700000000) return; // الوقت لسه مايتزامنش من الإنترنت (NTP)

  t += (long)schedGmtOffset * 3600L; // تطبيق فرق التوقيت المحلي يدويًا
  struct tm *tmNow = gmtime(&t);
  int curMinutes = tmNow->tm_hour * 60 + tmNow->tm_min;

  for (int i = 0; i < RELAY_COUNT; i++) {
    if (!schedEnabled[i]) continue;

    int onMinutes  = schedOnHour[i] * 60 + schedOnMinute[i];
    int offMinutes = schedOffHour[i] * 60 + schedOffMinute[i];

    bool shouldBeOn;
    if (onMinutes == offMinutes) {
      shouldBeOn = false; // إعداد متطابق، اعتبره مقفول
    } else if (onMinutes < offMinutes) {
      shouldBeOn = (curMinutes >= onMinutes && curMinutes < offMinutes);
    } else {
      shouldBeOn = (curMinutes >= onMinutes || curMinutes < offMinutes); // الجدول بيعدي نص الليل
    }

    if (shouldBeOn != relayState[i]) {
      setRelay(i, shouldBeOn);
      Serial.println((shouldBeOn ? "⏰ الجدول: تشغيل " : "⏰ الجدول: إيقاف ") + relayNames[i]);
    }
  }
}

// ============================================================
//                       إشعار ntfy.sh
// ============================================================
void sendNtfyNotification(String title, String message) {
  if (ntfyTopic.length() == 0) {
    Serial.println("⚠️ ntfy: مفيش اسم توبيك محفوظ، الإشعار اتلغى.");
    return;
  }
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("⚠️ ntfy: مفيش اتصال بالإنترنت (الراوتر)، الإشعار اتلغى.");
    return;
  }

  WiFiClientSecure client;
  client.setInsecure(); // نتخطى التحقق من الشهادة عشان نبسّط الاتصال
  client.setBufferSizes(512, 512); // بيقلل استهلاك الرام في الـ SSL - بيمنع فشل صامت على ESP8266
  HTTPClient https;
  https.setTimeout(8000);

  String url = "https://ntfy.sh/" + ntfyTopic;
  Serial.println("🔔 بعتنا إشعار لـ: " + url + " | رام فاضي: " + String(ESP.getFreeHeap()));
  if (https.begin(client, url)) {
    https.addHeader("Title", title);
    https.addHeader("Priority", "urgent");
    https.addHeader("Tags", "rotating_light");
    int code = https.POST(message);
    if (code > 0) {
      Serial.printf("✅ ntfy notification result: %d\n", code);
    } else {
      Serial.printf("❌ ntfy فشل الإرسال، كود الخطأ: %d (%s)\n", code, https.errorToString(code).c_str());
    }
    https.end();
  } else {
    Serial.println("❌ فشل فتح الاتصال بـ ntfy.sh (مشكلة رام أو شبكة)");
  }
}

// ============================================================
//   تصريح مسبق (Forward declarations) لدوال الـ MQTT topics
//   لازم عشان دي بتُستخدم في activateEmergency/deactivateEmergency
//   تحت، قبل ما توصل لمكان تعريفها الأصلي في الكود
// ============================================================
String topicControl(int index);
String topicStatus(int index);
String topicControlAll();
String topicStatusAll();
String topicControlEmergency();
String topicStatusEmergency();
String topicControlEmergencyButton();
String topicStatusEmergencyButton();
String topicControlTestNotify();
String topicStatusTestNotify();
String topicDiscovery();

// ============================================================
//                       زرار الطوارئ (Emergency Button)
// ============================================================
void activateEmergency() {
  if (emergencyActive) return; // شغال بالفعل، متجاهلش الضغطة
  emergencyActive = true;
  emergencyStartTime = millis();

  for (int i = 0; i < RELAY_COUNT; i++) {
    if (!emergencyRelayEnabled[i]) continue;
    relayState[i] = true;
    digitalWrite(relayPins[i], RELAY_ACTIVE_LOW ? LOW : HIGH);
    publishStatus(i);
  }

  if (mqttClient.connected()) {
    mqttClient.publish(topicStatusEmergency().c_str(), "ON", true);
    if (emergencyShareTopic.length() > 0) {
      mqttClient.publish(emergencyShareTopic.c_str(), "ON", true); // بث للبورد التاني
    }
  }

  Serial.println("🚨 تم تفعيل زرار الطوارئ!");
  sendNtfyNotification(
    "🚨 طوارئ - " + panelTitle,
    "تم تفعيل وضع الطوارئ! المفاتيح المحددة اشتغلت وهتفضل شغالة لمدة 30 دقيقة."
  );
}

void deactivateEmergency(bool notify = false) {
  if (!emergencyActive) return;
  emergencyActive = false;

  for (int i = 0; i < RELAY_COUNT; i++) {
    if (!emergencyRelayEnabled[i]) continue;
    relayState[i] = false;
    digitalWrite(relayPins[i], RELAY_ACTIVE_LOW ? HIGH : LOW);
    publishStatus(i);
  }

  if (mqttClient.connected()) {
    mqttClient.publish(topicStatusEmergency().c_str(), "OFF", true);
    if (emergencyShareTopic.length() > 0) {
      mqttClient.publish(emergencyShareTopic.c_str(), "OFF", true); // بث للبورد التاني
    }
  }

  Serial.println("تم إيقاف وضع الطوارئ");
  if (notify) {
    sendNtfyNotification("✅ " + panelTitle, "تم إيقاف وضع الطوارئ يدويًا.");
  }
}

void checkEmergencyButton() {
  bool pressed = (digitalRead(emergencyButtonPin) == LOW);

  if (pressed && !emergencyButtonHeld) {
    delay(30); // ديباونس بسيط
    if (digitalRead(emergencyButtonPin) == LOW) {
      emergencyButtonHeld = true;
      if (emergencyButtonEnabled && millis() - emergencyLastTrigger > EMERGENCY_RETRIGGER_COOLDOWN) {
        emergencyLastTrigger = millis();
        activateEmergency();
      }
    }
  } else if (!pressed) {
    emergencyButtonHeld = false;
  }
}

void checkEmergencyTimer() {
  if (emergencyActive && millis() - emergencyStartTime >= EMERGENCY_DURATION) {
    deactivateEmergency(false);
  }
}

// ============================================================
//                       MQTT
// ============================================================
String topicControl(int index) { return mqttPrefix + "/control/relay" + String(index + 1); }
String topicStatus(int index)  { return mqttPrefix + "/status/relay" + String(index + 1); }
String topicControlAll() { return mqttPrefix + "/control/all"; }
String topicStatusAll()  { return mqttPrefix + "/status/all"; }
String topicControlEmergency() { return mqttPrefix + "/control/emergency"; }
String topicStatusEmergency()  { return mqttPrefix + "/status/emergency"; }
String topicControlEmergencyButton() { return mqttPrefix + "/control/emergencybutton"; }
String topicStatusEmergencyButton()  { return mqttPrefix + "/status/emergencybutton"; }
String topicControlTestNotify() { return mqttPrefix + "/control/testnotify"; }
String topicStatusTestNotify()  { return mqttPrefix + "/status/testnotify"; }
String topicDiscovery()         { return mqttPrefix + "/discovery"; }

// ============================================================
//         Discovery (اكتشاف البورد) - نفس بروتوكول التطبيق بالظبط
// ============================================================
// بيبني نفس الـ "canonical string" اللي التطبيق بيبنيه في discovery.js
// (buildCanonicalString) بنفس الترتيب بالظبط، وبيوقّعه بـ HMAC-SHA256
// باستخدام "مفتاح الربط". أي اختلاف بسيط في الترتيب أو الفواصل هيخلي
// التوقيع مايتطابقش والتطبيق هيرفض البورد.
// ملحوظة (ESP8266): هنا بنستخدم مكتبة Crypto (rweather) بدل mbedtls،
// لأن mbedtls جزء من ESP-IDF بتاع ESP32 بس، وESP8266 SDK (BearSSL) مالوش
// نفس الـ API. مكتبة Crypto بتديلنا نفس النتيجة (HMAC-SHA256) بشكل خفيف جدًا.
String hmacSha256Hex(const String& key, const String& message) {
  SHA256 sha256;
  byte hmacResult[32];

  sha256.resetHMAC((const uint8_t*)key.c_str(), key.length());
  sha256.update((const uint8_t*)message.c_str(), message.length());
  sha256.finalizeHMAC((const uint8_t*)key.c_str(), key.length(), hmacResult, sizeof(hmacResult));

  String hex = "";
  char buf[3];
  for (int i = 0; i < 32; i++) {
    sprintf(buf, "%02x", hmacResult[i]);
    hex += buf;
  }
  return hex;
}

// بيبني جزء المفاتيح (swPart) بنفس ترتيب discovery.js بالظبط:
// name,control_topic,status_topic,icon,control_type  --- مفصولة بـ ; بين كل مفتاح
// بعد الريليهات، بنضيف "مفتاح" وهمي بيمثّل زرار الطوارئ نفسه — بنفس شكل أي
// مفتاح عادي (control_topic + status_topic) عشان يظهر في التطبيق كجهاز
// قابل للتحكم فيه ومتابعة حالته، رغم إنه فعليًا زرار فيزيائي + أمر MQTT.
String buildSwitchesCanonicalPart() {
  String swPart = "";
  for (int i = 0; i < RELAY_COUNT; i++) {
    if (i > 0) swPart += ";";
    swPart += relayNames[i] + "," + topicControl(i) + "," + topicStatus(i) + ",lamp,toggle";
  }
  swPart += ";زرار الطوارئ," + topicControlEmergency() + "," + topicStatusEmergency() + ",emergency-button,toggle";
  // زرار اختبار البورد - بيظهر في التطبيق زي أي مفتاح عادي، لما تدوسه بيبعت
  // إشعار تجريبي على ntfy ويرجع "OFF" تاني فورًا (زرار لحظي مش سويتش دايم).
  swPart += ";زرار اختبار البورد," + topicControlTestNotify() + "," + topicStatusTestNotify() + ",bell,toggle";
  return swPart;
}

void publishDiscovery() {
  if (!mqttClient.connected()) return;
  if (pairingKey.length() == 0) return; // لازم مفتاح ربط قبل ما نبعت اكتشاف

  String deviceId = mqttPrefix;
  String name = panelTitle;
  String type = "switches";
  String prefixField = ""; // فاضية لبورد switches (زي ما discovery.js متوقع)
  String swPart = buildSwitchesCanonicalPart();

  // نفس ترتيب buildCanonicalString في discovery.js:
  // [device_id, name, type, prefix, swPart].join('|')
  String canonical = deviceId + "|" + name + "|" + type + "|" + prefixField + "|" + swPart;
  String sig = hmacSha256Hex(pairingKey, canonical);

  DynamicJsonDocument doc(2304);
  doc["device_id"] = deviceId;
  doc["name"] = name;
  doc["type"] = type;
  JsonArray switches = doc.createNestedArray("switches");
  for (int i = 0; i < RELAY_COUNT; i++) {
    JsonObject sw = switches.createNestedObject();
    sw["name"] = relayNames[i];
    sw["control_topic"] = topicControl(i);
    sw["status_topic"] = topicStatus(i);
    sw["icon"] = "lamp";
    sw["control_type"] = "toggle";
  }
  // زرار الطوارئ نفسه، بنفس ترتيب buildSwitchesCanonicalPart بالظبط —
  // لازم يفضل آخر عنصر هنا عشان التوقيع يتطابق.
  JsonObject emSw = switches.createNestedObject();
  emSw["name"] = "زرار الطوارئ";
  emSw["control_topic"] = topicControlEmergency();
  emSw["status_topic"] = topicStatusEmergency();
  emSw["icon"] = "emergency-button";
  emSw["control_type"] = "toggle";

  // زرار اختبار البورد (لازم يفضل آخر عنصر بعد زرار الطوارئ، بنفس ترتيب
  // buildSwitchesCanonicalPart بالظبط عشان التوقيع يتطابق).
  JsonObject testSw = switches.createNestedObject();
  testSw["name"] = "زرار اختبار البورد";
  testSw["control_topic"] = topicControlTestNotify();
  testSw["status_topic"] = topicStatusTestNotify();
  testSw["icon"] = "bell";
  testSw["control_type"] = "toggle";

  doc["sig"] = sig;

  String payload;
  serializeJson(doc, payload);

  mqttClient.publish(topicDiscovery().c_str(), payload.c_str(), true /* retained */);
}

void publishStatus(int index) {
  if (!mqttClient.connected()) return;
  mqttClient.publish(topicStatus(index).c_str(), relayState[index] ? "ON" : "OFF", true);
}

void publishAllStatus() {
  if (!mqttClient.connected()) return;
  for (int i = 0; i < RELAY_COUNT; i++) publishStatus(i);
}

void publishEmergencyButtonStatus() {
  if (!mqttClient.connected()) return;
  mqttClient.publish(topicStatusEmergencyButton().c_str(), emergencyButtonEnabled ? "ON" : "OFF", true);
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String msg;
  for (unsigned int i = 0; i < length; i++) msg += (char)payload[i];
  msg.trim();
  bool state = msg.equalsIgnoreCase("ON");

  String t = String(topic);

  if (t == topicControlAll()) {
    setAllRelays(state);
    return;
  }

  if (t == topicControlEmergency()) {
    if (state) activateEmergency();
    else deactivateEmergency(true);
    return;
  }

  if (emergencyShareTopic.length() > 0 && t == emergencyShareTopic) {
    // أمر جاي من البورد التاني (أو نفس البورد) عن طريق التوبيك المشترك
    if (state) activateEmergency();
    else deactivateEmergency(true);
    return;
  }

  if (t == topicControlEmergencyButton()) {
    emergencyButtonEnabled = state;
    saveEmergencyButtonEnabled(state);
    publishEmergencyButtonStatus();
    return;
  }

  if (t == topicControlTestNotify()) {
    sendNtfyNotification("🔔 اختبار - " + panelTitle, "الإشعارات شغالة تمام! دي رسالة تجريبية من التطبيق، من غير ما نلمس أي مفتاح.");
    if (mqttClient.connected()) {
      // بترجع "OFF" فورًا (بدل ما تفضل ON) عشان الزرار يبان في التطبيق كأنه
      // زرار لحظي (نبضة) اتضغط ورجع، مش سويتش هيفضل شغال.
      mqttClient.publish(topicStatusTestNotify().c_str(), "OFF", true);
    }
    return;
  }

  for (int i = 0; i < RELAY_COUNT; i++) {
    if (t == topicControl(i)) {
      setRelay(i, state);
      return;
    }
  }
}

void mqttReconnect() {
  if (!mqttEnabled) return;
  if (mqttClient.connected()) return;
  if (WiFi.status() != WL_CONNECTED) return;

  String clientId = "MostafaBadawyESP8266-" + String(ESP.getChipId(), HEX);
  if (mqttClient.connect(clientId.c_str())) {
    mqttClient.subscribe(topicControlAll().c_str());
    mqttClient.subscribe(topicControlEmergency().c_str());
    mqttClient.subscribe(topicControlEmergencyButton().c_str());
    mqttClient.subscribe(topicControlTestNotify().c_str());
    if (emergencyShareTopic.length() > 0) {
      mqttClient.subscribe(emergencyShareTopic.c_str());
    }
    for (int i = 0; i < RELAY_COUNT; i++) {
      mqttClient.subscribe(topicControl(i).c_str());
    }
    publishDiscovery();
    publishAllStatus();
    publishEmergencyButtonStatus();
    mqttClient.publish(topicStatusTestNotify().c_str(), "OFF", true); // حالة ابتدائية لزرار الاختبار
  }
}

// ============================================================
//                       WiFi
// ============================================================
void startAccessPoint() {
  WiFi.softAP(apSsid.c_str(), apPass.c_str(), 1, apHidden ? 1 : 0);
  Serial.print("Access Point: ");
  Serial.println(apSsid);
  Serial.print("AP IP: ");
  Serial.println(WiFi.softAPIP());
}

// يحاول يظبط IP ثابت على الواي فاي (STA). لو أي قيمة غلط أو فاضية، بيرجع false
// وساعتها البورد هياخد IP عادي (تلقائي) من الروتر عادي من غير ما يبوظ حاجة
bool applyStaticIpIfNeeded() {
  if (!staUseStaticIp) return false;

  IPAddress ip, gw, sub, dns;
  if (!ip.fromString(staStaticIp)) return false;
  if (!gw.fromString(staStaticGateway)) return false;
  if (!sub.fromString(staStaticSubnet)) sub = IPAddress(255, 255, 255, 0);

  if (staStaticDns.length() > 0) {
    if (!dns.fromString(staStaticDns)) dns = gw;
  } else {
    dns = gw;
  }

  bool ok = WiFi.config(ip, gw, sub, dns);
  if (ok) {
    Serial.print("تم ضبط IP ثابت: ");
    Serial.println(ip);
  } else {
    Serial.println("فشل ضبط الـ IP الثابت، هيتم الاعتماد على DHCP");
  }
  return ok;
}

void connectToWifi() {
  if (staSsid.length() == 0) return;

  applyStaticIpIfNeeded(); // لازم قبل WiFi.begin

  WiFi.begin(staSsid.c_str(), staPass.c_str());
  Serial.print("جاري الاتصال بـ: ");
  Serial.println(staSsid);

  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
    delay(300);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("متصل! IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("فشل الاتصال بالشبكة، هيتم الاعتماد على الـ Access Point فقط");
  }
}

// ============================================================
//                       HTML Helpers  (Tuya-style modern UI)
// ============================================================
// ============================================================
//   CSS الصفحات - متخزن في الفلاش (PROGMEM) ومتبعتش جوه كل صفحة
// ============================================================
// ده نفس الـ CSS اللي كان قبل كده متكرر جوه كل response كـ <style> -
// دلوقتي بيتبعت مرة واحدة بس من /style.css والمتصفح بيكاشيه (Cache-Control)،
// فبيوفر: (1) حجم كل صفحة بيتبعتها البورد (أخف بكتير وأسرع تحميل)
// و(2) رام البورد (متبنيش نص طويل كـ String في كل Request زي الأول -
// وده اللي كان بيسبب "تفتت الرام" Heap Fragmentation بمرور الوقت).
// شلنا كمان من bottomnav خاصية transform/will-change/backface-visibility
// اللي كانت بتجبر المتصفح يعمل طبقة GPU مستقلة - مفيدة على أجهزة قوية
// بس بتتقل على موبايلات ضعيفة وتسبب تقطيع/اختفاء الشريط السفلي.
const char PAGE_CSS[] PROGMEM = R"CSS(
*{box-sizing:border-box;}
body{background:linear-gradient(180deg,#0f1720 0%,#0a0e14 100%);color:#eaeaea;font-family:'Segoe UI',Tahoma,Arial,sans-serif;margin:0;padding-bottom:90px;min-height:100vh;}
.appbar{display:flex;align-items:center;justify-content:space-between;padding:18px 20px;background:#121c26;box-shadow:0 2px 10px rgba(0,0,0,.4);position:sticky;top:0;z-index:10;}
.appbar h1{font-size:19px;margin:0;font-weight:600;}
.status-dot{display:inline-block;width:10px;height:10px;border-radius:50%;background:#2ecc71;margin-left:8px;box-shadow:0 0 8px #2ecc71;}
.subtitle{color:#8a96a3;font-size:12px;margin-top:2px;}
.container{max-width:520px;margin:0 auto;padding:16px;}
.quickrow{display:flex;gap:10px;margin-bottom:18px;}
.pill{flex:1;text-align:center;padding:14px;border-radius:16px;font-weight:700;text-decoration:none;font-size:15px;color:#fff;transition:.2s;}
.pill:active{transform:scale(.96);}
.pill-on{background:linear-gradient(135deg,#1fb87a,#17a367);}
.pill-off{background:linear-gradient(135deg,#e6544a,#c9392f);}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
.card{background:#141e29;border-radius:18px;padding:16px;position:relative;box-shadow:0 4px 14px rgba(0,0,0,.35);border:1px solid #1f2b38;}
.card-icon{font-size:26px;margin-bottom:6px;}
.card-name{font-size:14.5px;font-weight:600;color:#f0f0f0;min-height:38px;line-height:1.3;}
.card-foot{display:flex;justify-content:space-between;align-items:center;margin-top:12px;}
.card-state{font-size:12px;color:#8a96a3;}
.switch{position:relative;display:inline-block;width:52px;height:30px;}
.switch input{display:none;}
.slider{position:absolute;cursor:pointer;inset:0;background:#3a4654;border-radius:30px;transition:.25s;}
.slider:before{content:'';position:absolute;width:24px;height:24px;left:3px;top:3px;background:#fff;border-radius:50%;transition:.25s;box-shadow:0 2px 4px rgba(0,0,0,.3);}
.switch input:checked + .slider{background:linear-gradient(135deg,#1fb87a,#17a367);}
.switch input:checked + .slider:before{transform:translateX(22px);}
.section{background:#141e29;border-radius:18px;padding:20px;margin:16px 0;border:1px solid #1f2b38;}
.section h2{margin-top:0;font-size:16px;color:#7fd1ff;}
.section p{color:#b7c1cc;font-size:13.5px;line-height:1.7;}
.info-box{background:#101820;border-radius:12px;padding:12px 14px;font-size:13px;color:#9db0c0;margin:12px 0;}
input[type=text],input[type=password],input[type=number]{width:100%;padding:13px 14px;margin:8px 0;border-radius:12px;border:1px solid #26313f;background:#0f1720;color:#fff;font-size:15px;}
input:focus{outline:none;border-color:#1fb87a;}
.btn{display:block;width:100%;margin:10px 0;padding:15px;border:none;border-radius:14px;font-size:16px;font-weight:700;cursor:pointer;text-decoration:none;text-align:center;color:#fff;transition:.2s;}
.btn:active{transform:scale(.98);}
.btn-green{background:linear-gradient(135deg,#1fb87a,#17a367);}
.btn-red{background:linear-gradient(135deg,#e6544a,#c9392f);}
.btn-blue{background:linear-gradient(135deg,#3d9be9,#2f7fc4);}
.btn-orange{background:linear-gradient(135deg,#f0a63f,#d98a1f);}
.btn-purple{background:linear-gradient(135deg,#a663d9,#8b46c2);}
.checkrow{display:flex;align-items:center;gap:8px;color:#c6cfd8;font-size:13.5px;margin:10px 0;}
.topics{text-align:right;background:#101820;border-radius:12px;padding:14px;font-size:13px;color:#c6cfd8;line-height:2;}
.topics span{color:#1fb87a;}
.bottomnav{position:fixed;bottom:0;left:0;right:0;background:#121c26;display:flex;justify-content:space-around;padding:10px 4px calc(14px + env(safe-area-inset-bottom));box-shadow:0 -4px 14px rgba(0,0,0,.4);z-index:999;}
.navitem{color:#8a96a3;text-decoration:none;text-align:center;font-size:11px;flex:1;}
.navitem .ic{display:block;font-size:20px;margin-bottom:2px;}
.navitem.active{color:#1fb87a;}
footer{color:#5a6472;margin:24px 0 10px;font-size:11.5px;text-align:center;}
footer a{color:#3d9be9;text-decoration:none;}
)CSS";

void handleStyleCss() {
  server.sendHeader("Cache-Control", "public, max-age=604800, immutable");
  server.send_P(200, "text/css", PAGE_CSS);
}

// ============================================================
//   إصلاح مشكلة "الصفحة بتقيل / السويتش بيشتغل بعد فترة"
// ============================================================
// السبب الحقيقي: مكتبة ESP8266WebServer بتسيب خوارزمية Nagle شغالة
// على كل اتصال، وده بيخلي أي رد صغير (زي رد الـ /control) يتأخر لحد
// ما يتجمع مع باكيتات تانية أو يعدي عليه مهلة الـ ACK بتاعة المتصفح -
// ده بالظبط اللي بيظهر كـ "بيشتغل بعد فترة". الحل المعروف والموثّق لكل
// مشاريع ESP8266WebServer هو تعطيل Nagle (TCP_NODELAY) على كل Client
// فور ما نستقبل الـ Request، عن طريق استدعاء الدالة دي أول حاجة في كل Handler.
inline void primeFastResponse() {
  server.client().setNoDelay(true);
}

String htmlHeader(String title) {
  String html = F("<!DOCTYPE html><html lang='ar' dir='rtl'><head>");
  html.reserve(600); // تخصيص مسبق للذاكرة يقلل إعادة التخصيص المتكرر (Heap Fragmentation)
  html += F("<meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1'>");
  html += "<title>" + title + "</title>";
  // الـ CSS بقى بيتقرأ من ملف مستقل (/style.css) بدل ما يتكرر جوه كل صفحة -
  // المتصفح بيحمله مرة واحدة بس وبيكاشيه، وده بيخفف حجم كل صفحة وبيقلل
  // استهلاك الرام في البورد لأنه مبقاش محتاج يبني نص الـ CSS الطويل ده
  // كـ String في كل Request (كان بيسبب تفتت رام - Heap Fragmentation).
  html += F("<link rel='stylesheet' href='/style.css'>");
  // بدل ما كل ضغطة على السويتش تعمل تنقل كامل للصفحة (يبني كل الـ HTML من جديد ويبطّئ الرد)،
  // بنبعت الطلب في الخلفية بس (fetch) ونحدّث شكل الكارت فورًا من غير أي إعادة تحميل.
  // الاسكريبت ده بيتبعت في كل صفحة، فخليناه في الفلاش (F()) مش في الرام عشان يقلل تفتت الرام.
  html += F("<script>function confirmGo(msg,url){if(confirm(msg)){window.location.href=url;}return false;}"
          "function toggleRelay(i,willOn){"
          "fetch('/control?relay='+i+'&state='+(willOn?'on':'off')+'&ajax=1');"
          "var st=document.getElementById('state'+i);if(st)st.textContent=willOn?'ON':'OFF';"
          "var ic=document.getElementById('icon'+i);if(ic)ic.textContent=willOn?'\\ud83d\\udca1':'\\ud83d\\udd0c';"
          "}"
          "function toggleAll(state){"
          "fetch('/control?relay=all&state='+state+'&ajax=1').then(function(){location.reload();});"
          "return false;"
          "}</script>");
  html += F("</head><body>");
  html += "<div class='appbar'><div><h1>" + panelTitle + "</h1>";
  html += F("<div class='subtitle'><span class='status-dot'></span>Online</div></div>");
  if (peerBoardUrl.length() > 0) {
    html += "<a href='http://" + peerBoardUrl + "/' style='font-size:19px;text-decoration:none;background:#1c2733;color:#7fd1ff;padding:9px 13px;border-radius:12px;' title='التنقل للبورد التاني'>🔀</a>";
  }
  html += F("</div>");
  return html;
}

String bottomNav(String active) {
  String html = "<div class='bottomnav'>";
  html += "<a class='navitem" + String(active == "home" ? " active" : "") + "' href='/'><span class='ic'>🏠</span>Home</a>";
  html += "<a class='navitem" + String(active == "wifi" ? " active" : "") + "' href='/wifi'><span class='ic'>📶</span>WiFi</a>";
  html += "<a class='navitem" + String(active == "names" ? " active" : "") + "' href='/relaynames'><span class='ic'>✏️</span>Names</a>";
  html += "<a class='navitem" + String(active == "mqtt" ? " active" : "") + "' href='/mqtt'><span class='ic'>📡</span>MQTT</a>";
  html += "<a class='navitem' href='#' onclick=\"return confirmGo('هل تريد إعادة تشغيل الجهاز؟','/restart')\"><span class='ic'>🔄</span>Restart</a>";
  html += F("</div>");
  return html;
}

String htmlFooter(String active) {
  String html = bottomNav(active);
  html += F("<footer>© 2026 Mostafa_Badawy_Controller_V2 — All Rights Reserved<br>");
  html += F("Contact: mostafabadwy12@gmail.com | Whatsapp: +201066339340</footer>");
  html += F("</body></html>");
  return html;
}

// ============================================================
//                       صفحة Home
// ============================================================
void handleRoot() {
  String html = htmlHeader(panelTitle);
  html.reserve(2600); // تخصيص مسبق يقلل تفتت الرام
  html += F("<div class='container'>");

  if (emergencyActive) {
    html += F("<div class='section' style='border-color:#e6544a;background:#2a1210;'>");
    html += F("<h2 style='color:#ff8a80;margin:0 0 6px;'>🚨 وضع الطوارئ شغال دلوقتي</h2>");
    html += F("<a href='/emergency' class='btn btn-red'>عرض التفاصيل / إيقاف</a>");
    html += F("</div>");
  }

  html += F("<div class='quickrow'>");
  html += "<a href='#' onclick=\"return toggleAll('on')\" class='pill pill-on'>⚡ All ON</a>";
  html += "<a href='#' onclick=\"return toggleAll('off')\" class='pill pill-off'>⏻ All OFF</a>";
  html += F("</div>");

  if (!emergencyButtonEnabled) {
    html += F("<div class='section' style='padding:10px 16px;margin-bottom:10px;border-color:#8a96a3;background:#1a2129;'>");
    html += F("<a href='/emergency' style='color:#8a96a3;text-decoration:none;'>⚪ زرار الطوارئ الفيزيائي متعطّل حاليًا (وضع أنا موجود في البيت)</a>");
    html += F("</div>");
  }

  html += F("<div class='grid'>");
  for (int i = 0; i < RELAY_COUNT; i++) {
    bool st = relayState[i];
    html += F("<div class='card'>");
    html += "<div class='card-icon' id='icon" + String(i) + "'>" + String(st ? "💡" : "🔌") + "</div>";
    html += "<div class='card-name'>" + relayNames[i] + "</div>";
    html += F("<div class='card-foot'>");
    html += "<span class='card-state' id='state" + String(i) + "'>" + String(st ? "ON" : "OFF") + "</span>";
    html += "<label class='switch'><input type='checkbox' " + String(st ? "checked" : "") + " ";
    html += "onclick=\"toggleRelay(" + String(i) + ",this.checked)\">";
    html += F("<span class='slider'></span></label>");
    html += F("</div></div>");
  }
  html += "</div>"; // grid

  int schedActiveCount = 0;
  for (int i = 0; i < RELAY_COUNT; i++) if (schedEnabled[i]) schedActiveCount++;

  html += F("<div class='section' style='padding:14px 16px;margin-bottom:10px;'>");
  html += "<a href='/schedule' class='btn btn-purple' style='margin:0;'>⏰ تايمر يومي لكل كشاف" + (schedActiveCount > 0 ? String(" - ") + String(schedActiveCount) + " شغال ✅" : String("")) + "</a>";
  html += F("</div>");

  html += "</div>"; // container
  html += htmlFooter("home");
  server.send(200, "text/html", html);
}

void handleControl() {
  String relay = server.arg("relay");
  String state = server.arg("state");
  bool st = (state == "on");

  if (relay == "all") {
    setAllRelays(st);
  } else {
    int idx = relay.toInt();
    setRelay(idx, st);
  }

  // طلبات الـ AJAX (اللي جايه من toggleRelay/toggleAll في الجافاسكريبت) بناخد لها
  // رد صغير وسريع من غير Redirect - ده اللي بيخلي السويتش يستجيب فورًا بدل
  // ما ينتظر تحميل صفحة / كاملة تاني (اللي كانت السبب الرئيسي في التأخير).
  if (server.hasArg("ajax")) {
    server.sendHeader("Connection", "close");
    server.send(200, "text/plain", "OK");
    return;
  }

  server.sendHeader("Location", "/");
  server.send(303);
}

// ============================================================
//                       صفحة WiFi Settings
// ============================================================
void handleWifiPage() {
  String html = htmlHeader("WiFi Settings");
  html.reserve(3200);
  html += F("<div class='container'>");

  html += F("<div class='section'><h2>📶 Current Connection Status</h2>");
  html += "<p>Status: " + String(WiFi.status() == WL_CONNECTED ? "✅ Connected" : "❌ Not Connected") + "<br>";
  html += "Network: " + (staSsid.length() ? staSsid : String("--")) + "<br>";
  html += "IP: " + (WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : String("--")) + "</p></div>";

  html += F("<div class='section' style='border-color:#1fb87a;background:#0f2016;'><h2>📡 Access Point (Always Available)</h2>");
  html += "<p>Network Name: " + apSsid + "<br>";
  html += "Password: " + apPass + "<br>";
  html += "Network Status: " + String(apHidden ? "🙈 Hidden" : "👁 Visible") + "<br>";
  html += F("AP IP: <b>192.168.4.1</b></p></div>");

  html += F("<div class='section'><h2>✏️ Enter Network Details Manually</h2>");
  html += F("<form action='/savewifi' method='POST'>");
  html += "<input type='text' name='ssid' placeholder='Network name (SSID)' value='" + staSsid + "'>";
  html += F("<input type='password' name='pass' placeholder='Password'>");
  html += F("<button class='btn btn-green' type='submit'>💾 Save and restart</button>");
  html += F("</form></div>");

  html += F("<div class='section'><h2>📡 Configure Access Point</h2>");
  html += F("<form action='/saveap' method='POST'>");
  html += "<input type='text' name='apssid' placeholder='Network name' value='" + apSsid + "'>";
  html += "<input type='password' name='appass' placeholder='Password' value='" + apPass + "'>";
  html += F("<input type='password' name='appass2' placeholder='Confirm AP Password'>");
  html += "<div class='checkrow'><input type='checkbox' name='hidden' id='hd' " + String(apHidden ? "checked" : "") + "><label for='hd'>🔒 Hide network name</label></div>";
  html += F("<button class='btn btn-green' type='submit'>💾 Save AP Settings</button>");
  html += F("</form></div>");

  html += F("<div class='section'><h2>📌 IP ثابت للبورد (Static IP)</h2>");
  html += F("<p>لو مفعّل، البورد هياخد نفس الـ IP دا كل مرة بدل ما يتغير من الروتر. لازم البيانات تكون متوافقة مع شبكتك (مثلاً لو الروتر 192.168.1.1، اكتب Gateway = 192.168.1.1 و IP من نفس الرينج زي 192.168.1.200).</p>");
  html += F("<form action='/savestaticip' method='POST'>");
  html += "<div class='checkrow'><input type='checkbox' name='sipen' id='sipen' " + String(staUseStaticIp ? "checked" : "") + "><label for='sipen'>📌 تفعيل IP ثابت</label></div>";
  html += "<input type='text' name='sipip' placeholder='IP الثابت (مثال: 192.168.1.200)' value='" + staStaticIp + "'>";
  html += "<input type='text' name='sipgw' placeholder='Gateway (عادة IP الروتر، مثال: 192.168.1.1)' value='" + staStaticGateway + "'>";
  html += "<input type='text' name='sipsub' placeholder='Subnet Mask' value='" + staStaticSubnet + "'>";
  html += "<input type='text' name='sipdns' placeholder='DNS (اختياري، سيبه فاضي لو مش عارف)' value='" + staStaticDns + "'>";
  html += F("<button class='btn btn-green' type='submit'>💾 حفظ وإعادة الاتصال</button>");
  html += F("</form></div>");

  html += F("<div class='section'><h2>🔀 بورد تاني على نفس الشبكة</h2>");
  html += F("<p>سيب الحقل فاضي لو مش عايز الأيقونة، أو اكتب آي بي البورد التاني (تقدر تشوفه من System Info بتاعه) عشان تظهرلك أيقونة تنقل بينهم في كل صفحة.</p>");
  html += F("<form action='/savepeer' method='POST'>");
  html += "<input type='text' name='peerip' placeholder='مثال: 192.168.1.50' value='" + peerBoardUrl + "'>";
  html += F("<button class='btn btn-green' type='submit'>💾 حفظ</button>");
  html += F("</form></div>");

  html += F("<div class='section'><h2>⚙️ Other Settings</h2>");
  html += F("<a href='/sysinfo' class='btn btn-blue'>ℹ️ System Info</a>");
  html += F("<a href='/emergency' class='btn btn-red'>🚨 Emergency Button Settings</a>");
  html += F("<a href='/system' class='btn btn-purple'>🛠️ System (OTA / Backup / Restore)</a>");
  html += "<a href='#' onclick=\"return confirmGo('هل تريد مسح كل الإعدادات المحفوظة؟','/clearsettings')\" class='btn btn-red'>🗑 Clear saved settings</a>";
  html += "<a href='#' onclick=\"return confirmGo('هل تريد إعادة تشغيل الجهاز؟','/restart')\" class='btn btn-blue'>🔄 Restart device</a>";
  html += F("<a href='/currentip' class='btn btn-blue'>🌐 Current IP Settings</a>");
  html += F("</div>");

  html += F("</div>");

  html += htmlFooter("wifi");
  server.send(200, "text/html", html);
}

void handleSavePeer() {
  peerBoardUrl = server.arg("peerip");
  peerBoardUrl.trim();
  savePeerBoard(peerBoardUrl);
  server.sendHeader("Location", "/wifi");
  server.send(303);
}

void handleSaveStaticIp() {
  bool en = server.hasArg("sipen");
  String ip  = server.arg("sipip");
  String gw  = server.arg("sipgw");
  String sub = server.arg("sipsub");
  String dns = server.arg("sipdns");
  ip.trim(); gw.trim(); sub.trim(); dns.trim();
  if (sub.length() == 0) sub = "255.255.255.0";

  IPAddress tmp;
  bool ipValid = tmp.fromString(ip);
  bool gwValid = tmp.fromString(gw);

  if (en && (!ipValid || !gwValid)) {
    server.send(200, "text/html", htmlHeader("خطأ") + "<div class='container'><div class='section'><h2>❌ الـ IP أو الـ Gateway اللي كتبته مش صحيح</h2><a href='/wifi' class='btn btn-blue'>رجوع</a></div></div>" + htmlFooter("wifi"));
    return;
  }

  staUseStaticIp   = en;
  staStaticIp      = ip;
  staStaticGateway = gw;
  staStaticSubnet  = sub;
  staStaticDns     = dns;
  saveStaticIpSettings(en, ip, gw, sub, dns);

  server.send(200, "text/html", htmlHeader("تم الحفظ") + "<div class='container'><div class='section'><h2>تم الحفظ، جاري إعادة الاتصال...</h2></div></div>" + htmlFooter("wifi"));
  delay(500);
  connectToWifi();
}

void handleSaveWifi() {
  String ssid = server.arg("ssid");
  String pass = server.arg("pass");
  if (ssid.length() > 0) {
    staSsid = ssid;
    staPass = pass;
    saveWifiSettings(ssid, pass);
  }
  server.send(200, "text/html", htmlHeader("Saved") + "<div class='container'><div class='section'><h2>تم الحفظ، جاري الاتصال بالشبكة...</h2></div></div>" + htmlFooter("wifi"));
  delay(500);
  connectToWifi();
}

void handleSaveAp() {
  String ssid = server.arg("apssid");
  String pass = server.arg("appass");
  String pass2 = server.arg("appass2");
  bool hidden = server.hasArg("hidden");

  if (pass2.length() > 0 && pass2 != pass) {
    server.send(200, "text/html", htmlHeader("خطأ") + "<div class='container'><div class='section'><h2>كلمة السر غير متطابقة</h2><a href='/wifi' class='btn btn-blue'>رجوع</a></div></div>" + htmlFooter("wifi"));
    return;
  }

  if (ssid.length() > 0 && pass.length() >= 8) {
    apSsid = ssid;
    apPass = pass;
    apHidden = hidden;
    saveApSettings(ssid, pass, hidden);
  }
  server.sendHeader("Location", "/wifi");
  server.send(303);
}

void handleClearSettings() {
  clearAllSettings();
  server.send(200, "text/html", htmlHeader("تم المسح") + "<div class='container'><div class='section'><h2>تم مسح كل الإعدادات، جاري إعادة التشغيل...</h2></div></div>" + htmlFooter("wifi"));
  delay(1500);
  ESP.restart();
}

void handleCurrentIp() {
  String html = htmlHeader("Current IP Settings");
  html.reserve(1800);
  html += F("<div class='container'><div class='section'>");
  html += "<p>STA IP: " + (WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : String("--")) + "<br>";
  html += "نوع الـ IP: " + String(staUseStaticIp ? "📌 ثابت (Static)" : "🔄 تلقائي من الروتر (DHCP)") + "<br>";
  html += "Gateway: " + (WiFi.status() == WL_CONNECTED ? WiFi.gatewayIP().toString() : String("--")) + "<br>";
  html += "Subnet: " + (WiFi.status() == WL_CONNECTED ? WiFi.subnetMask().toString() : String("--")) + "<br>";
  html += "AP IP: " + WiFi.softAPIP().toString() + "<br>";
  html += "MAC: " + WiFi.macAddress() + "</p></div>";
  html += F("<a href='/wifi' class='btn btn-blue'>⬅ رجوع</a></div>");
  html += htmlFooter("wifi");
  server.send(200, "text/html", html);
}

// ============================================================
//                       صفحة Edit Names + Timer
// ============================================================
void handleRelayNamesPage() {
  String html = htmlHeader("Edit Names");
  html.reserve(1700);
  html += F("<div class='container'>");

  html += F("<div class='section'><h2>🏷️ Panel Title</h2>");
  html += F("<form action='/savetitle' method='POST'>");
  html += "<input type='text' name='title' value='" + panelTitle + "'>";
  html += F("<button class='btn btn-purple' type='submit'>💾 Save Title</button>");
  html += F("</form></div>");

  html += F("<div class='section'><h2>✏️ Change Device Names</h2>");
  html += F("<p>غيّر اسم أي ريليه من هنا</p>");
  html += F("<form action='/saverelaynames' method='POST'>");

  for (int i = 0; i < RELAY_COUNT; i++) {
    html += "<h3 style='color:#7fd1ff;font-size:14px;margin-bottom:4px;'>🔷 Relay " + String(i + 1) + "</h3>";
    html += "<input type='text' name='name" + String(i) + "' value='" + relayNames[i] + "'>";
  }

  html += F("<p style='color:#8a96a3;font-size:12.5px;'><b>ملاحظة:</b> بعد حفظ الأسماء، الصفحة الرئيسية هتتحدث تلقائي</p>");
  html += F("<button class='btn btn-green' type='submit'>💾 Save New Names</button>");
  html += F("</form></div>");

  html += F("</div>");
  html += htmlFooter("names");
  server.send(200, "text/html", html);
}

void handleSaveRelayNames() {
  for (int i = 0; i < RELAY_COUNT; i++) {
    String nameKey = "name" + String(i);
    if (server.hasArg(nameKey)) {
      String val = server.arg(nameKey);
      if (val.length() > 0) relayNames[i] = val;
    }
  }
  saveRelayNamesAndTimers();
  publishDiscovery(); // أسماء المفاتيح اتغيرت، لازم نبعت رسالة اكتشاف جديدة موقّعة عليها
  server.sendHeader("Location", "/");
  server.send(303);
}

void handleSaveTitle() {
  String title = server.arg("title");
  if (title.length() > 0) {
    panelTitle = title;
    savePanelTitle(title);
    publishDiscovery(); // اسم البورد اتغير، لازم نبعت رسالة اكتشاف جديدة موقّعة عليها
  }
  server.sendHeader("Location", "/relaynames");
  server.send(303);
}

// ============================================================
//                       صفحة MQTT Settings
// ============================================================
void handleMqttPage() {
  String html = htmlHeader("MQTT Settings");
  html.reserve(2200);
  html += F("<div class='container'>");
  html += F("<div class='section'><h2>📡 Configure MQTT Broker</h2>");
  html += F("<div class='info-box'>ℹ️ هذه الإعدادات تتحكم في اتصال MQTT. التغييرات تسري بعد إعادة التشغيل.</div>");
  html += F("<form action='/savemqtt' method='POST'>");
  html += "<input type='text' name='broker' value='" + mqttBroker + "' placeholder='Broker address'>";
  html += "<input type='text' name='prefix' value='" + mqttPrefix + "' placeholder='Topic Prefix'>";
  html += "<input type='number' name='port' value='" + String(mqttPort) + "' placeholder='Port'>";

  html += F("<hr style='border-color:rgba(217,164,90,.25);margin:18px 0;'>");
  html += F("<label style='display:block;color:#d1d5db;font-size:13.5px;margin-bottom:8px;'>🔑 مفتاح الربط (Pairing Key) — نفس المفتاح المكتوب في إعدادات التطبيق بالظبط:</label>");
  html += "<input type='text' name='pairingkey' value='" + pairingKey + "' placeholder='مفتاح الربط'>";
  html += F("<div class='info-box'>ℹ️ المفتاح ده بيخلي التطبيق يتأكد إن البورد ده هو بتاعك فعلاً قبل ما يضيفه. اكتب أي نص سري تختاره، وحط نفس النص بالظبط في إعدادات الاتصال بالتطبيق.</div>");

  html += F("<div class='topics'><b>Topics format:</b><br>");
  html += "Control: <span>" + mqttPrefix + "/control/relay1</span><br>";
  html += "Status: <span>" + mqttPrefix + "/status/relay1</span><br>";
  html += "Control All: <span>" + mqttPrefix + "/control/all</span><br>";
  html += "Status All: <span>" + mqttPrefix + "/status/all</span><br>";
  html += "Emergency (ON/OFF): <span>" + mqttPrefix + "/control/emergency</span><br>";
  html += "Emergency Button Enable (ON/OFF): <span>" + mqttPrefix + "/control/emergencybutton</span><br>";
  html += "Emergency Button Status: <span>" + mqttPrefix + "/status/emergencybutton</span></div>";

  html += F("<button class='btn btn-green' type='submit'>💾 Save MQTT Settings</button>");
  html += F("</form></div></div>");
  html += htmlFooter("mqtt");
  server.send(200, "text/html", html);
}

void handleSaveMqtt() {
  String broker = server.arg("broker");
  String prefix = server.arg("prefix");
  int port = server.arg("port").toInt();
  String pkey = server.arg("pairingkey");

  if (broker.length() > 0) mqttBroker = broker;
  if (prefix.length() > 0) mqttPrefix = prefix;
  if (port > 0) mqttPort = port;
  pairingKey = pkey;

  saveMqttSettings(mqttBroker, mqttPrefix, mqttPort);
  savePairingKey(pairingKey);

  server.send(200, "text/html", htmlHeader("Saved") + "<div class='container'><div class='section'><h2>تم الحفظ، جاري إعادة التشغيل...</h2></div></div>" + htmlFooter("mqtt"));
  delay(1500);
  ESP.restart();
}

// ============================================================
//                       صفحة زرار الطوارئ
// ============================================================
void handleEmergencyPage() {
  String html = htmlHeader("Emergency Button");
  html.reserve(3800);
  if (emergencyActive) {
    html.replace("</head>", "<meta http-equiv='refresh' content='5'></head>");
  }
  html += F("<div class='container'>");

  if (emergencyActive) {
    unsigned long remain = (EMERGENCY_DURATION - (millis() - emergencyStartTime)) / 1000;
    unsigned long remainMin = remain / 60;
    unsigned long remainSec = remain % 60;
    html += F("<div class='section' style='border-color:#e6544a;background:#2a1210;'><h2 style='color:#ff8a80;'>🚨 وضع الطوارئ شغال</h2>");
    html += "<p>الوقت المتبقي: " + String(remainMin) + " دقيقة و" + String(remainSec) + " ثانية</p>";
    html += "<a href='#' onclick=\"return confirmGo('هل تريد إيقاف وضع الطوارئ الآن؟','/cancelemergency')\" class='btn btn-red'>⛔ إيقاف الطوارئ الآن</a>";
    html += F("</div>");
  } else {
    html += F("<div class='section'><h2>🚨 حالة الطوارئ</h2><p>غير مفعّل حاليًا</p></div>");
  }

  html += F("<div class='section'><h2>🔘 عن زرار الطوارئ</h2>");
  html += "<p>وصّل زرار فيزيائي بين البين <b>GPIO" + String(emergencyButtonPin) + "</b> والجراوند (GND). لما حد يضغطه، المفاتيح اللي هتحددها تحت هتشتغل تلقائي لمدة 30 دقيقة، وهيوصلك إشعار على موبايلك في نفس اللحظة.</p>";
  html += F("</div>");

  html += F("<div class='section'><h2>💡 أنهي مفاتيح تشتغل وقت الطوارئ (في البورد ده)</h2>");
  html += F("<p>حدد المفاتيح اللي عايزها تشتغل تلقائي وقت الطوارئ في البورد ده بالذات - سواء اتفعلت من الزرار الفيزيائي، من المتصفح، أو جاية من البورد التاني.</p>");
  html += F("<form action='/saveemergencyrelays' method='POST'>");
  for (int i = 0; i < RELAY_COUNT; i++) {
    html += "<div class='checkrow'><input type='checkbox' name='r" + String(i) + "' id='emr" + String(i) + "' " + String(emergencyRelayEnabled[i] ? "checked" : "") + "><label for='emr" + String(i) + "'>" + relayNames[i] + "</label></div>";
  }
  html += F("<button class='btn btn-green' type='submit'>💾 حفظ اختيار المفاتيح</button>");
  html += F("</form>");
  html += F("</div>");

  html += F("<div class='section'><h2>🔀 ربط الطوارئ بالبورد التاني (MQTT)</h2>");
  html += F("<div class='info-box'>");
  html += F("لو عندك بورد تاني وعايز الطوارئ تتفعل عنده هو كمان لما تتفعل هنا (والعكس):<br>");
  html += F("1) اكتب أي اسم توبيك مشترك (مثلاً: mostafa_home_emergency)<br>");
  html += F("2) اكتب نفس الاسم بالظبط في صفحة Emergency بتاعة البورد التاني<br>");
  html += F("3) البوردين لازم يكونوا متصلين بنفس MQTT Broker (نفس السيرفر في صفحة MQTT Settings)<br>");
  html += F("4) كل بورد هيشغل بس المفاتيح اللي حددتها له هو في القسم اللي فوق");
  html += F("</div>");
  html += F("<form action='/saveemshared' method='POST'>");
  html += "<input type='text' name='shtopic' placeholder='مثال: mostafa_home_emergency' value='" + emergencyShareTopic + "'>";
  html += F("<button class='btn btn-green' type='submit'>💾 حفظ التوبيك المشترك</button>");
  html += F("</form>");
  html += F("</div>");

  html += "<div class='section' style='" + String(emergencyButtonEnabled ? "" : "border-color:#8a96a3;background:#1a2129;") + "'>";
  html += "<h2>" + String(emergencyButtonEnabled ? "🟢 الزرار مفعّل" : "⚪ الزرار متعطّل") + "</h2>";
  if (emergencyButtonEnabled) {
    html += F("<p>الزرار الفيزيائي شغال دلوقتي. لو انت موجود في البيت وعايز حد يدوس عليه غلط ميشغلش حاجة، عطّله من هنا.</p>");
    html += "<a href='#' onclick=\"return confirmGo('هيتم تعطيل زرار الطوارئ الفيزيائي، متابع؟','/toggleemergencybutton')\" class='btn btn-red'>⛔ تعطيل الزرار (أنا موجود في البيت)</a>";
  } else {
    html += F("<p>الزرار الفيزيائي متعطّل دلوقتي، لو حد ضغط عليه مش هيحصل حاجة. فعّله تاني وانت خارج البيت.</p>");
    html += "<a href='#' onclick=\"return confirmGo('هيتم تفعيل زرار الطوارئ الفيزيائي، متابع؟','/toggleemergencybutton')\" class='btn btn-green'>✅ تفعيل الزرار تاني</a>";
  }
  html += F("</div>");

  html += F("<div class='section'><h2>🔔 إعدادات إشعار الموبايل (ntfy)</h2>");
  html += F("<div class='info-box'>");
  html += F("1) نزّل تطبيق <b>ntfy</b> من App Store أو Google Play<br>");
  html += F("2) افتح التطبيق واعمل Subscribe لاسم توبيك (Topic) خاص بيك - افضل تختار اسم غريب وصعب حد يخمنه عشان محدش تاني يقدر يشوف إشعاراتك<br>");
  html += F("3) اكتب نفس الاسم بالظبط هنا واحفظ");
  html += F("</div>");
  html += F("<form action='/savenotify' method='POST'>");
  html += "<input type='text' name='topic' placeholder='مثال: mostafa-home-alert-9821' value='" + ntfyTopic + "'>";
  html += F("<button class='btn btn-green' type='submit'>💾 حفظ اسم التوبيك</button>");
  html += F("</form>");
  if (ntfyTopic.length() > 0) {
    html += F("<a href='/testnotify' class='btn btn-blue'>🔔 إرسال إشعار تجريبي</a>");
  }
  html += F("</div>");

  if (!emergencyActive) {
    html += F("<div class='section'><h2>📱 تفعيل الطوارئ من الموبايل (وانت بره البيت)</h2>");
    html += F("<p>دوس على الزرار ده وانت بره البيت عشان تشغّل المفاتيح المحددة فورًا، بنفس تأثير الزرار الفيزيائي بالظبط.</p>");
    html += "<a href='#' onclick=\"return confirmGo('هيتم تشغيل المفاتيح المحددة فعليًا لمدة 30 دقيقة، متابع؟','/triggeremergency')\" class='btn btn-orange'>🚨 تفعيل الطوارئ الآن</a>";
    html += F("</div>");
  }

  html += F("</div>");
  html += htmlFooter("wifi");
  server.send(200, "text/html", html);
}

void handleSaveNotify() {
  String topic = server.arg("topic");
  topic.trim();
  ntfyTopic = topic;
  saveNtfyTopic(topic);
  server.sendHeader("Location", "/emergency");
  server.send(303);
}

void handleTestNotify() {
  sendNtfyNotification("🔔 اختبار - " + panelTitle, "الإشعارات شغالة تمام! دي رسالة تجريبية من زرار الطوارئ.");
  server.sendHeader("Location", "/emergency");
  server.send(303);
}

void handleToggleEmergencyButton() {
  emergencyButtonEnabled = !emergencyButtonEnabled;
  saveEmergencyButtonEnabled(emergencyButtonEnabled);
  publishEmergencyButtonStatus();
  server.sendHeader("Location", "/emergency");
  server.send(303);
}

void handleSaveEmergencyRelays() {
  for (int i = 0; i < RELAY_COUNT; i++) {
    emergencyRelayEnabled[i] = server.hasArg("r" + String(i));
  }
  saveEmergencyRelaySelection();
  server.sendHeader("Location", "/emergency");
  server.send(303);
}

void handleSaveEmergencyShareTopic() {
  String topic = server.arg("shtopic");
  topic.trim();
  bool wasSubscribed = emergencyShareTopic.length() > 0;
  emergencyShareTopic = topic;
  saveEmergencyShareTopic(topic);
  if (mqttClient.connected() && emergencyShareTopic.length() > 0) {
    mqttClient.subscribe(emergencyShareTopic.c_str()); // اشترك فورًا من غير ما نستنى إعادة تشغيل
  }
  server.sendHeader("Location", "/emergency");
  server.send(303);
}

void handleTriggerEmergency() {
  activateEmergency();
  server.sendHeader("Location", "/emergency");
  server.send(303);
}

void handleCancelEmergency() {
  deactivateEmergency(true);
  server.sendHeader("Location", "/emergency");
  server.send(303);
}

// ============================================================
//                 صفحة الإضاءة التلقائية (ليل/نهار)
// ============================================================
// ============================================================
//                 صفحة تايمر المواعيد (الكشاف)
// ============================================================
void handleSchedulePage() {
  String html = htmlHeader("Schedule Timer");
  html.reserve(4200);
  html.replace("</head>", "<meta http-equiv='refresh' content='20'></head>"); // تحديث الوقت الحالي كل 20 ثانية
  html += F("<div class='container'>");

  time_t t = time(nullptr);
  bool timeSynced = (t >= 1700000000);
  html += F("<div class='section'><h2>🕒 الوقت الحالي</h2>");
  if (timeSynced) {
    time_t local = t + (long)schedGmtOffset * 3600L;
    struct tm *tmNow = gmtime(&local);
    char buf[32];
    snprintf(buf, sizeof(buf), "%02d:%02d:%02d", tmNow->tm_hour, tmNow->tm_min, tmNow->tm_sec);
    html += "<p>الوقت دلوقتي عند الجهاز: <b>" + String(buf) + "</b></p>";
  } else {
    html += F("<p style='color:#f0a63f;'>⏳ الوقت لسه بيتزامن من الإنترنت... تأكد إن الجهاز متصل بالواي فاي (لازم إنترنت فعلي مش بس شبكة محلية)</p>");
  }
  html += F("</div>");

  html += F("<div class='section'><h2>🌍 فرق التوقيت (مشترك لكل الجداول)</h2>");
  html += F("<form action='/savescheduletz' method='POST' style='display:flex;gap:10px;align-items:center;'>");
  html += "<input type='number' name='gmt' min='-12' max='14' value='" + String(schedGmtOffset) + "' style='flex:1;margin:0;'>";
  html += F("<button class='btn btn-blue' type='submit' style='width:auto;margin:0;padding:13px 18px;'>💾</button>");
  html += F("</form>");
  html += F("<p style='color:#8a96a3;font-size:12px;margin-bottom:0;'>فرق التوقيت عن جرينتش بالساعات (مصر = 2)</p>");
  html += F("</div>");

  // جدول تشغيل/إيقاف مستقل لكل ريليه (كشاف)
  for (int i = 0; i < RELAY_COUNT; i++) {
    html += F("<div class='section'>");
    html += "<h2>💡 " + relayNames[i] + (schedEnabled[i] ? " - شغال ✅" : "") + "</h2>";

    if (timeSynced && schedEnabled[i]) {
      html += "<p style='margin-top:0;'>حالة الريليه دلوقتي: <b>" + String(relayState[i] ? "شغال" : "مقفول") + "</b></p>";
    }

    html += F("<form action='/saveschedule' method='POST'>");
    html += "<input type='hidden' name='relay' value='" + String(i) + "'>";

    html += "<div class='checkrow'><input type='checkbox' name='en' id='schen" + String(i) + "' " + String(schedEnabled[i] ? "checked" : "") + ">";
    html += "<label for='schen" + String(i) + "'>⏰ تفعيل تايمر يومي لـ " + relayNames[i] + "</label></div>";

    html += F("<p style='color:#8a96a3;font-size:12.5px;margin-bottom:4px;'>ميعاد التشغيل (الفتح):</p>");
    html += F("<div style='display:flex;gap:10px;'>");
    html += "<input type='number' name='onh' min='0' max='23' value='" + String(schedOnHour[i]) + "' placeholder='ساعة' style='flex:1;'>";
    html += "<input type='number' name='onm' min='0' max='59' value='" + String(schedOnMinute[i]) + "' placeholder='دقيقة' style='flex:1;'>";
    html += F("</div>");

    html += F("<p style='color:#8a96a3;font-size:12.5px;margin-bottom:4px;'>ميعاد الإيقاف (القفل):</p>");
    html += F("<div style='display:flex;gap:10px;'>");
    html += "<input type='number' name='offh' min='0' max='23' value='" + String(schedOffHour[i]) + "' placeholder='ساعة' style='flex:1;'>";
    html += "<input type='number' name='offm' min='0' max='59' value='" + String(schedOffMinute[i]) + "' placeholder='دقيقة' style='flex:1;'>";
    html += F("</div>");

    html += "<button class='btn btn-green' type='submit' style='margin-top:14px;'>💾 حفظ تايمر " + relayNames[i] + "</button>";
    html += F("</form>");
    html += F("</div>");
  }

  html += F("<p style='color:#8a96a3;font-size:12px;'>ملحوظة: لو ميعاد الإيقاف قبل ميعاد التشغيل (مثلاً يفتح 6 مساءً ويقفل 6 صباحًا)، النظام بيتعامل معاه صح وبيعدي نص الليل عادي.</p>");

  html += F("</div>");
  html += htmlFooter("home");
  server.send(200, "text/html", html);
}

void handleSaveSchedule() {
  int relay = server.arg("relay").toInt();
  if (relay < 0 || relay >= RELAY_COUNT) {
    server.sendHeader("Location", "/schedule");
    server.send(303);
    return;
  }

  bool en = server.hasArg("en");
  int onh = server.arg("onh").toInt();
  int onm = server.arg("onm").toInt();
  int offh = server.arg("offh").toInt();
  int offm = server.arg("offm").toInt();

  if (onh < 0 || onh > 23) onh = schedOnHour[relay];
  if (onm < 0 || onm > 59) onm = schedOnMinute[relay];
  if (offh < 0 || offh > 23) offh = schedOffHour[relay];
  if (offm < 0 || offm > 59) offm = schedOffMinute[relay];

  schedEnabled[relay]  = en;
  schedOnHour[relay]   = onh;
  schedOnMinute[relay] = onm;
  schedOffHour[relay]  = offh;
  schedOffMinute[relay] = offm;

  saveScheduleForRelay(relay, en, onh, onm, offh, offm);
  server.sendHeader("Location", "/schedule");
  server.send(303);
}

void handleSaveScheduleTz() {
  int gmt = server.arg("gmt").toInt();
  if (gmt >= -12 && gmt <= 14) {
    schedGmtOffset = gmt;
    saveScheduleGmt(gmt);
  }
  server.sendHeader("Location", "/schedule");
  server.send(303);
}

// ============================================================
//                       صفحة System Info
// ============================================================
String formatUptime(unsigned long ms) {
  unsigned long totalSec = ms / 1000;
  unsigned long days = totalSec / 86400;
  unsigned long hours = (totalSec % 86400) / 3600;
  unsigned long mins = (totalSec % 3600) / 60;
  unsigned long secs = totalSec % 60;

  String out = "";
  if (days > 0) out += String(days) + "d ";
  out += String(hours) + "h " + String(mins) + "m " + String(secs) + "s";
  return out;
}

String rssiQuality(int rssi) {
  if (rssi >= -55) return "ممتاز 📶";
  if (rssi >= -70) return "جيد 📶";
  if (rssi >= -80) return "ضعيف 📶";
  return "ضعيف جدًا 📶";
}

void handleSysInfoPage() {
  bool wifiOk = (WiFi.status() == WL_CONNECTED);
  bool mqttOk = mqttClient.connected();

  String html = htmlHeader("System Info");
  html.reserve(2000);
  html.replace("</head>", "<meta http-equiv='refresh' content='5'></head>");

  html += F("<div class='container'>");

  html += F("<div class='section'><h2>ℹ️ System Info</h2>");

  html += F("<div class='info-box'>");
  html += "🌐 <b>IP Address:</b> " + (wifiOk ? WiFi.localIP().toString() : WiFi.softAPIP().toString()) + (wifiOk ? "" : " (Access Point)") + "<br>";
  html += "🔗 <b>MAC Address:</b> " + WiFi.macAddress() + "<br>";
  html += "📶 <b>RSSI:</b> " + (wifiOk ? (String(WiFi.RSSI()) + " dBm — " + rssiQuality(WiFi.RSSI())) : String("--")) + "<br>";
  html += "🧠 <b>Free Heap:</b> " + String(ESP.getFreeHeap() / 1024) + " KB<br>";
  html += "💾 <b>Flash Size:</b> " + String(ESP.getFlashChipSize() / (1024 * 1024)) + " MB<br>";
  html += "⏱️ <b>Uptime:</b> " + formatUptime(millis());
  html += F("</div>");

  html += F("<div class='card-foot' style='margin-top:14px;'>");
  html += "<span>WiFi: <b style='color:" + String(wifiOk ? "#1fb87a" : "#e6544a") + "'>" + String(wifiOk ? "Connected ✅" : "Disconnected ❌") + "</b></span>";
  html += F("</div>");
  html += F("<div class='card-foot' style='margin-top:8px;'>");
  html += "<span>MQTT: <b style='color:" + String(mqttOk ? "#1fb87a" : "#e6544a") + "'>" + String(mqttOk ? "Connected ✅" : "Disconnected ❌") + "</b></span>";
  html += F("</div>");

  html += F("<p style='color:#5a6472;font-size:11.5px;margin-top:16px;text-align:center;'>🔄 الصفحة بتتحدث تلقائي كل 5 ثواني</p>");
  html += F("</div></div>");

  html += htmlFooter("wifi");
  server.send(200, "text/html", html);
}

// ============================================================
//                       صفحة System (OTA / Backup / Restore)
// ============================================================
void handleSystemPage() {
  String html = htmlHeader("System");
  html.reserve(2500);
  html += F("<div class='container'>");

  html += F("<div class='section'><h2>⬆️ OTA Firmware Update</h2>");
  html += F("<div class='info-box'>ارفع ملف <b>.bin</b> من مجلد <code>.pio/build/nodemcuv2/firmware.bin</code> بعد عمل Build. الجهاز هيعيد التشغيل تلقائي بعد نجاح التحديث.</div>");
  html += "<form method='POST' action='/otaupload' enctype='multipart/form-data' onsubmit=\"return confirm('هل تريد رفع فيرموير جديد؟ متقفلش الصفحة أثناء الرفع.')\">";
  html += F("<input type='file' name='firmware' accept='.bin' required style='width:100%;padding:12px;border-radius:12px;background:#0f1720;border:1px solid #26313f;color:#fff;margin:8px 0;'>");
  html += F("<button class='btn btn-orange' type='submit'>⬆️ Upload &amp; Flash</button>");
  html += F("</form></div>");

  html += F("<div class='section'><h2>💾 Backup Settings</h2>");
  html += F("<p>حمّل ملف يحتوي كل إعداداتك الحالية (الشبكة، الأسماء، MQTT) عشان ترجعله وقت ما تحتاج.</p>");
  html += F("<a href='/backup' class='btn btn-blue'>⬇️ Download Backup File</a>");
  html += F("</div>");

  html += F("<div class='section'><h2>♻️ Restore Settings</h2>");
  html += F("<p>ارفع ملف backup.json اللي حفظته قبل كده، هيرجّع كل الإعدادات ويعيد تشغيل الجهاز.</p>");
  html += "<form method='POST' action='/restorefile' enctype='multipart/form-data' onsubmit=\"return confirm('هل تريد استرجاع الإعدادات من الملف؟ الإعدادات الحالية هتتستبدل.')\">";
  html += F("<input type='file' name='backupfile' accept='.json' required style='width:100%;padding:12px;border-radius:12px;background:#0f1720;border:1px solid #26313f;color:#fff;margin:8px 0;'>");
  html += F("<button class='btn btn-purple' type='submit'>♻️ Restore</button>");
  html += F("</form></div>");

  html += F("</div>");
  html += htmlFooter("wifi");
  server.send(200, "text/html", html);
}

// ------------------- OTA Update -------------------
void handleOtaFileUpload() {
  HTTPUpload& upload = server.upload();

  if (upload.status == UPLOAD_FILE_START) {
    otaUploadOk = false;
    otaErrorMsg = "";
    Serial.printf("OTA Update بدأ: %s\n", upload.filename.c_str());
    if (!Update.begin(0xFFFFFFFF)) {
      otaErrorMsg = "فشل بدء التحديث (المساحة غير كافية؟)";
      Update.printError(Serial);
    }
  } else if (upload.status == UPLOAD_FILE_WRITE) {
    if (Update.write(upload.buf, upload.currentSize) != upload.currentSize) {
      otaErrorMsg = "فشل كتابة البيانات أثناء التحديث";
      Update.printError(Serial);
    }
  } else if (upload.status == UPLOAD_FILE_END) {
    if (Update.end(true)) {
      otaUploadOk = true;
      Serial.printf("تم التحديث بنجاح: %u بايت\n", upload.totalSize);
    } else {
      otaErrorMsg = "فشل إنهاء التحديث - الملف غير صالح";
      Update.printError(Serial);
    }
  } else if (upload.status == UPLOAD_FILE_ABORTED) {
    Update.end();
    otaErrorMsg = "تم إلغاء رفع الملف";
  }
}

void handleOtaUploadResult() {
  server.sendHeader("Connection", "close");
  if (otaUploadOk) {
    server.send(200, "text/html", htmlHeader("OTA") + "<div class='container'><div class='section'><h2>✅ تم التحديث بنجاح، جاري إعادة التشغيل...</h2></div></div>" + htmlFooter("wifi"));
    delay(1500);
    ESP.restart();
  } else {
    String msg = otaErrorMsg.length() > 0 ? otaErrorMsg : "فشل التحديث";
    server.send(200, "text/html", htmlHeader("OTA") + "<div class='container'><div class='section'><h2>❌ " + msg + "</h2><a href='/system' class='btn btn-blue'>رجوع</a></div></div>" + htmlFooter("wifi"));
  }
}

// ------------------- Backup -------------------
void handleBackup() {
  DynamicJsonDocument doc(3072);

  doc["panelTitle"] = panelTitle;
  doc["staSsid"] = staSsid;
  doc["staPass"] = staPass;
  doc["apSsid"] = apSsid;
  doc["apPass"] = apPass;
  doc["apHidden"] = apHidden;
  doc["mqttBroker"] = mqttBroker;
  doc["mqttPrefix"] = mqttPrefix;
  doc["mqttPort"] = mqttPort;

  JsonArray relays = doc.createNestedArray("relays");
  for (int i = 0; i < RELAY_COUNT; i++) {
    JsonObject r = relays.createNestedObject();
    r["name"] = relayNames[i];
  }

  String output;
  serializeJsonPretty(doc, output);

  server.sendHeader("Content-Disposition", "attachment; filename=backup.json");
  server.send(200, "application/json", output);
}

// ------------------- Restore -------------------
void handleRestoreFileUpload() {
  HTTPUpload& upload = server.upload();

  if (upload.status == UPLOAD_FILE_START) {
    restoreBuffer = "";
  } else if (upload.status == UPLOAD_FILE_WRITE) {
    for (size_t i = 0; i < upload.currentSize; i++) {
      restoreBuffer += (char)upload.buf[i];
    }
  }
}

bool applyRestoreJson(String &jsonText) {
  DynamicJsonDocument doc(3072);
  DeserializationError err = deserializeJson(doc, jsonText);
  if (err) return false;

  panelTitle = doc["panelTitle"] | panelTitle;
  staSsid    = doc["staSsid"] | staSsid;
  staPass    = doc["staPass"] | staPass;
  apSsid     = doc["apSsid"] | apSsid;
  apPass     = doc["apPass"] | apPass;
  apHidden   = doc["apHidden"] | apHidden;
  mqttBroker = doc["mqttBroker"] | mqttBroker;
  mqttPrefix = doc["mqttPrefix"] | mqttPrefix;
  mqttPort   = doc["mqttPort"] | mqttPort;

  JsonArray relays = doc["relays"];
  if (!relays.isNull()) {
    for (int i = 0; i < RELAY_COUNT && i < (int)relays.size(); i++) {
      JsonObject r = relays[i];
      relayNames[i] = (r["name"] | relayNames[i].c_str());
    }
  }

  savePanelTitle(panelTitle);
  saveWifiSettings(staSsid, staPass);
  saveApSettings(apSsid, apPass, apHidden);
  saveMqttSettings(mqttBroker, mqttPrefix, mqttPort);
  saveRelayNamesAndTimers();

  return true;
}

void handleRestoreResult() {
  bool ok = applyRestoreJson(restoreBuffer);
  restoreBuffer = "";

  if (ok) {
    server.send(200, "text/html", htmlHeader("Restore") + "<div class='container'><div class='section'><h2>✅ تم استرجاع الإعدادات، جاري إعادة التشغيل...</h2></div></div>" + htmlFooter("wifi"));
    delay(1500);
    ESP.restart();
  } else {
    server.send(200, "text/html", htmlHeader("Restore") + "<div class='container'><div class='section'><h2>❌ الملف غير صالح</h2><a href='/system' class='btn btn-blue'>رجوع</a></div></div>" + htmlFooter("wifi"));
  }
}

// ============================================================
//                       Restart
// ============================================================
void handleRestart() {
  server.send(200, "text/html", htmlHeader("Restart") + "<div class='container'><div class='section'><h2>جاري إعادة التشغيل...</h2></div></div>" + htmlFooter("home"));
  delay(1000);
  ESP.restart();
}

// ============================================================
//                       Factory Reset
// ============================================================
// الزرار الفيزيائي اتشال (مفيش بين فاضي بعد الـ8 ريليهات) - استخدم
// زرار "مسح الإعدادات" من صفحة System في المتصفح بدلاً منه

// ============================================================
//                       Setup / Loop
// ============================================================
void setup() {
  Serial.begin(115200);

  for (int i = 0; i < RELAY_COUNT; i++) {
    pinMode(relayPins[i], OUTPUT);
    digitalWrite(relayPins[i], RELAY_ACTIVE_LOW ? HIGH : LOW); // تأكيد إن الريليه مقفول عند الإقلاع
  }
  pinMode(emergencyButtonPin, INPUT_PULLUP); // وصّل الزرار بين البين ده والجراوند

  loadSettings();

  WiFi.mode(WIFI_AP_STA);
  startAccessPoint();      // الـ Access Point شغال دايمًا
  connectToWifi();         // ومحاولة الاتصال بالشبكة المحفوظة كمان

  mqttClient.setServer(mqttBroker.c_str(), mqttPort);
  mqttClient.setCallback(mqttCallback);
  // لازم نكبّر بافر PubSubClient (افتراضيًا 256 بايت بس)، لأن رسالة الـ discovery
  // (فيها كل أسماء المفاتيح + التوبيكات + التوقيع) بتتعدى الـ 1000 بايت.
  // من غير السطر ده، publish() بتاع الـ discovery بيفشل بصمت من غير أي خطأ ظاهر،
  // والتطبيق مايشوفش البورد أبدًا حتى لو مفتاح الربط صح 100%.
  mqttClient.setBufferSize(2048);

  configTime(0, 0, "pool.ntp.org", "time.nist.gov"); // مزامنة الوقت (UTC) - لازم إنترنت فعلي عشان تشتغل ميزة الجدول

  // كل الـ Handlers دلوقتي بتعمل primeFastResponse() أول حاجة (تعطيل Nagle)
  // عشان تحل مشكلة "الصفحة بتقيل / السويتش بيشتغل بعد فترة"
  server.on("/", [](){ primeFastResponse(); handleRoot(); });
  server.on("/style.css", [](){ primeFastResponse(); handleStyleCss(); });
  server.on("/control", [](){ primeFastResponse(); handleControl(); });

  server.on("/wifi", [](){ primeFastResponse(); handleWifiPage(); });
  server.on("/savewifi", HTTP_POST, [](){ primeFastResponse(); handleSaveWifi(); });
  server.on("/savestaticip", HTTP_POST, [](){ primeFastResponse(); handleSaveStaticIp(); });
  server.on("/savepeer", HTTP_POST, [](){ primeFastResponse(); handleSavePeer(); });
  server.on("/saveap", HTTP_POST, [](){ primeFastResponse(); handleSaveAp(); });
  server.on("/clearsettings", [](){ primeFastResponse(); handleClearSettings(); });
  server.on("/currentip", [](){ primeFastResponse(); handleCurrentIp(); });

  server.on("/relaynames", [](){ primeFastResponse(); handleRelayNamesPage(); });
  server.on("/saverelaynames", HTTP_POST, [](){ primeFastResponse(); handleSaveRelayNames(); });
  server.on("/savetitle", HTTP_POST, [](){ primeFastResponse(); handleSaveTitle(); });

  server.on("/mqtt", [](){ primeFastResponse(); handleMqttPage(); });
  server.on("/savemqtt", HTTP_POST, [](){ primeFastResponse(); handleSaveMqtt(); });

  server.on("/system", [](){ primeFastResponse(); handleSystemPage(); });
  server.on("/sysinfo", [](){ primeFastResponse(); handleSysInfoPage(); });
  server.on("/otaupload", HTTP_POST, [](){ primeFastResponse(); handleOtaUploadResult(); }, handleOtaFileUpload);
  server.on("/backup", [](){ primeFastResponse(); handleBackup(); });
  server.on("/restorefile", HTTP_POST, [](){ primeFastResponse(); handleRestoreResult(); }, handleRestoreFileUpload);

  server.on("/emergency", [](){ primeFastResponse(); handleEmergencyPage(); });
  server.on("/saveemergencyrelays", HTTP_POST, [](){ primeFastResponse(); handleSaveEmergencyRelays(); });
  server.on("/saveemshared", HTTP_POST, [](){ primeFastResponse(); handleSaveEmergencyShareTopic(); });
  server.on("/savenotify", HTTP_POST, [](){ primeFastResponse(); handleSaveNotify(); });
  server.on("/testnotify", [](){ primeFastResponse(); handleTestNotify(); });
  server.on("/triggeremergency", [](){ primeFastResponse(); handleTriggerEmergency(); });
  server.on("/toggleemergencybutton", [](){ primeFastResponse(); handleToggleEmergencyButton(); });
  server.on("/cancelemergency", [](){ primeFastResponse(); handleCancelEmergency(); });

  server.on("/schedule", [](){ primeFastResponse(); handleSchedulePage(); });
  server.on("/saveschedule", HTTP_POST, [](){ primeFastResponse(); handleSaveSchedule(); });
  server.on("/savescheduletz", HTTP_POST, [](){ primeFastResponse(); handleSaveScheduleTz(); });

  server.on("/restart", [](){ primeFastResponse(); handleRestart(); });

  server.begin();
  Serial.println("تم تشغيل السيرفر بنجاح");
}

void loop() {
  server.handleClient();
  checkEmergencyButton();
  checkEmergencyTimer();
  checkSchedule();

  if (mqttEnabled) {
    if (!mqttClient.connected()) {
      static unsigned long lastAttempt = 0;
      if (millis() - lastAttempt > 5000) {
        lastAttempt = millis();
        mqttReconnect();
      }
    } else {
      mqttClient.loop();
    }
  }
}
